"""Backward-compatible web module import shim."""

from app.web.module import WebModule

__all__ = ["WebModule"]
